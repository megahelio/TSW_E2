<?php
class Tipos
{
    public $tipos;

    public
    function __construct(){
    $this->tipos = array("food", "bills", "leisure", "rent");
    }

}

?>