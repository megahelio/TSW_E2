<?php
// file: view/layouts/language_select_element.php
?>

<div>
    <img id="logoIMG" src="./view/Imgs/logo.png" alt="">
</div>

<div class="links">
    <ul><a class="link" href="index.php?controller=users&amp;action=index"><?= i18n("Home")?></a></ul>
    <ul><a class="link" href="index.php?controller=users&amp;action=register"><?= i18n("Register")?></a></ul>
    <ul><a class="link" href="index.php?controller=users&amp;action=login"><?= i18n("Login")?></a></ul>
</div>