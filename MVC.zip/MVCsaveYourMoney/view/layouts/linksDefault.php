<?php
// file: view/layouts/language_select_element.php
?>

<div class="links">
    <ul><a class="link" href="index.php?controller=gastos&amp;action=index"><?= i18n("Sumary")?></a></ul>
    <ul><a class="link" href="index.php?controller=gastos&amp;action=listarGastos"><?= i18n("spends List")?></a></ul>
</div>